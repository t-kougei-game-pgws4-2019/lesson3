# Code Editor Package for Visual Studio

## [1.0.5] - 2019-04-18

Fix relative package paths.
Fix opening editor on mac.

## [1.0.4] - 2019-04-12

- Fixing null reference issue for callbacks to AssetPostProcessor.
- Ensure Path.GetFullPath does not get an empty string.

## [1.0.3] - 2019-01-01

### This is the first release of *Unity Package visualstudio_editor*.

Using the newly created api to integrate Visual Studio with Unity.
